package com.example.djshichaoren.googleocrtest2.services;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.projection.MediaProjectionManager;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.CalendarContract;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.example.djshichaoren.googleocrtest2.MainActivity;
import com.example.djshichaoren.googleocrtest2.R;
import com.example.djshichaoren.googleocrtest2.models.FloatElementPool;
import com.example.djshichaoren.googleocrtest2.models.RecognizeResult;
import com.example.djshichaoren.googleocrtest2.util.GoogleOcr;
import com.example.djshichaoren.googleocrtest2.util.ScreenShotter;

import java.util.ArrayList;
import java.util.List;

/**
 * 类描述：
 * 修改人：DJSHICHAOREN
 * 修改时间：2019/7/13 21:51
 * 修改备注：
 */
public class ShowTranslationService extends Service {
    public static boolean isStarted = false;
    private WindowManager windowManager;
    private WindowManager.LayoutParams layoutParams;
    private ShowTranslationBinder mBinder = new ShowTranslationBinder();
    private ScreenShotter mScreenShotter;
    private GoogleOcr mGoogleOcr;
    private FloatElementPool<TextView> mFloatButtonPool;
    private List<TextView> mDisplayedButtonList = new ArrayList<>();
    @Override
    public void onCreate() {
        super.onCreate();
        isStarted = true;
        // 初始化windowManager
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        // 初始化layoutParams
        layoutParams = new WindowManager.LayoutParams();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
        //获取MediaProjectionManager实例
//        MediaProjectionManager mediaProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
//        mScreenShotter = new ScreenShotter(windowManager);
        Log.w("lwd", "Create translation service");
        mGoogleOcr = new GoogleOcr(getApplicationContext());
        mFloatButtonPool = new FloatElementPool<>(TextView.class, getApplicationContext(), 20);
        setForegroundNotification();
    }

    private void setForegroundNotification(){
        String CHANNEL_ONE_ID = "com.primedu.cn";
        String CHANNEL_ONE_NAME = "Channel One";
        NotificationChannel notificationChannel = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            notificationChannel = new NotificationChannel(CHANNEL_ONE_ID,
                    CHANNEL_ONE_NAME, NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.setShowBadge(true);
            notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(notificationChannel);
        }
        Notification notification = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this).setChannelId(CHANNEL_ONE_ID)
                    .setTicker("Nature")
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("xxxx")
                    .setContentText("xxxxx")
                    .getNotification();
        }
        else{
            notification = new Notification.Builder(this)
                    .setTicker("Nature")
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle("xxxx")
                    .setContentText("xxxxx")
                    .getNotification();
        }
        notification.flags |= Notification.FLAG_NO_CLEAR;
        startForeground(1, notification);
    }


    public void removeShowingButton(){
        for (TextView textView : mDisplayedButtonList) {
            windowManager.removeView(textView);
            mFloatButtonPool.deleteElement(textView);
        }
        mDisplayedButtonList.clear();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void showRecognizeResult(ArrayList<RecognizeResult> recognizeResultList){
//        removeShowingButton();
        for(RecognizeResult recognizeResult : recognizeResultList){
            showOneRecognizeResult(recognizeResult.mLeft, recognizeResult.mTop,
                    recognizeResult.mWidth, recognizeResult.mHeight, recognizeResult.mContent);
        }
//        removeShowingButton();
    }


    public void showOneRecognizeResult(int x, int y, int width, int height, String text){
        Log.w("lwd", "show one button " + String.format("x: %d, y:%d, width:%d, height:%d, string:%s", x, y, width, height, text));
//        if (Settings.canDrawOverlays(this)) {
//
//            layoutParams.format = PixelFormat.RGBA_8888;
//            layoutParams.gravity = Gravity.LEFT | Gravity.TOP;
//            layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
//            layoutParams.x = x;
//            layoutParams.y = y;
//            layoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
//            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
//
//            TextView element = mFloatButtonPool.getFloatElement();
//            element.setBackgroundColor(Color.WHITE);
//            if(element == null){
//                return;
//            }
//            element.setText(text);
//
//            windowManager.addView(element, layoutParams);
//            mDisplayedButtonList.add(element);
//        }
    }

    public void createScreenShotButton(){
        layoutParams.format = PixelFormat.RGBA_8888;
        layoutParams.gravity = Gravity.LEFT | Gravity.TOP;
        layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        layoutParams.width = 500;
        layoutParams.height = 100;
        layoutParams.x = 300;
        layoutParams.y = 300;
        Button button = new Button(getApplicationContext());
        button.setText("screen shot");

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap mScreenShotImage = mScreenShotter.takeScreenshot();
            }
        });
        windowManager.addView(button, layoutParams);
    }

    public void startRecognizeScreen(){
        final int TIME = 1000;
        final Handler mRecognizeHandler = new Handler();
        mRecognizeHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.d("lwd", "recognize screen once");
                removeShowingButton();

                Bitmap screenImage = mScreenShotter.takeScreenshot();
                if(screenImage != null){
                    ArrayList<RecognizeResult> recognizeResultsList = mGoogleOcr.recognize(screenImage);
                    showRecognizeResult(recognizeResultsList);
                }
                mRecognizeHandler.postDelayed(this, TIME);
            }
        }, TIME);
    }


    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    public class ShowTranslationBinder extends Binder{
        public ShowTranslationService getService(ScreenShotter screenShotter){
            mScreenShotter = screenShotter;
            return ShowTranslationService.this;
        }
    }
}
