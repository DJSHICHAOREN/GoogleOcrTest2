package com.example.djshichaoren.googleocrtest2.util;

import android.app.Activity;
import android.app.Application;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;


import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.util.Date;

/**
 * 类描述：
 * 修改人：DJSHICHAOREN
 * 修改时间：2019/7/19 23:46
 * 修改备注：
 */
public class ScreenShotter {
    private Activity mActivity;
    static Handler handler = new Handler();
    private int mScreenWidth;
    private int mScreenHeight;
    private int mScreenDpi;
    private ImageReader mImageReader;
    private MediaProjection mMediaProjection;
    private static final String TAG = "lwd";
    private VirtualDisplay mVirtualDisplay = null;
    private Bitmap mScreenShotImage;

    public ScreenShotter(final WindowManager windowManager) {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //获取屏幕的宽高和DPI
                Display display = windowManager.getDefaultDisplay();
                DisplayMetrics metrics = new DisplayMetrics();
                display.getRealMetrics(metrics);
//                Point size = new Point();
//                display.getRealSize(size);
                mScreenWidth = metrics.widthPixels;
                mScreenHeight = metrics.heightPixels;
//                mScreenWidth = size.x;
//                mScreenHeight = size.y;
                mScreenDpi = metrics.densityDpi;
                //初始化ImageReader实例
                mImageReader = ImageReader.newInstance(mScreenWidth, mScreenHeight, PixelFormat.RGBA_8888, 2);

            }
        }, 1000);
    }

    public void bindSystemScreenShot(MediaProjection mediaProjection) {
        mMediaProjection = mediaProjection;

        Log.i(TAG, "Setting up a VirtualDisplay: " +
                mScreenWidth + "x" + mScreenHeight +
                " (" + mScreenDpi + ")");

        mVirtualDisplay = mMediaProjection.createVirtualDisplay("ScreenCapture",
                mScreenWidth, mScreenHeight, mScreenDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                mImageReader.getSurface(), null, null);
    }


    public Bitmap takeScreenshot() {
        Image image = mImageReader.acquireLatestImage();
        if(image == null){
            return null;
        }

        int width = image.getWidth();
        int height = image.getHeight();
        final Image.Plane[] planes = image.getPlanes();
        final ByteBuffer buffer = planes[0].getBuffer();
        int pixelStride = planes[0].getPixelStride();
        int rowStride = planes[0].getRowStride();
        int rowPadding = rowStride - pixelStride * width;
        Bitmap bitmap = Bitmap.createBitmap(width+rowPadding/pixelStride, height, Bitmap.Config.ARGB_8888);
        bitmap.copyPixelsFromBuffer(buffer);
        bitmap = Bitmap.createBitmap(bitmap, 0, 0,width, height);
        image.close();

        mScreenShotImage = bitmap;

        return bitmap;
    }

    public Bitmap getScreenShotImage(){
        return mScreenShotImage;
    }

}