package com.example.djshichaoren.googleocrtest2.models;

/**
 * 类描述：
 * 修改人：DJSHICHAOREN
 * 修改时间：2019/7/16 23:05
 * 修改备注：
 */
public class RecognizeResult {
    public int mTop;
    public int mLeft;
    public int mWidth;
    public int mHeight;
    public String mContent;

    public RecognizeResult(int top, int left, int width, int height, String content){
        mTop = top;
        mLeft = left;
        mWidth = width;
        mHeight = height;
        mContent = content;
    }
}
